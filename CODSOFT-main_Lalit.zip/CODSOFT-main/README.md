# CODSOFT
This Repository includes project developed during CODSOFT Web Development Internship

## 🧮 Calculator
- [Live Demo](https://shaqib-7.github.io/CODSOFT/CALCULATOR/)

## 🚀 Landing Page
- [Live Demo](https://shaqib-7.github.io/CODSOFT/LANDING_PAGE/)

## First Personal Portfolio
- [Live Demo](https://shaqib-7.github.io/CODSOFT/PORTFOLIO/)
